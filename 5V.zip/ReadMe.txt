Three Viruses for the Elven-kings under the sky,
Seven for the Dwarf-lords in their halls of files,
Nine for Mortal Men doomed to be hacked,
One for the Dark Lord on his dark throne
In the Land of Files where the Viruses lie.
One Virus to rule them all, One Virus to find them,
One Virus to bring them all and in the darkness bind them
In the Land of Files where the Viruses lie.